

对 HybridCLR 代码热更新框架的扩展。

注意：请在导入此扩展包之前导入 HybridCLR 插件，不然会报错。

Github 仓库：https://github.com/focus-creative-games/hybridclr_unity
Gitee 镜像：https://gitee.com/focus-creative-games/hybridclr_unity
示例项目 Github 仓库：https://github.com/focus-creative-games/hybridclr_trial

下载安装
	通过PackageManager安装
	打开管理界面 Window/Package Manager
	点击左上角加号
	选择 Add package from git URL...
	输入以上 Github 连接

	其他安装方式请查看以下教程
	教程：https://focus-creative-games.github.io/hybridclr/install/#%E5%AE%89%E8%A3%85hybridclr-package
