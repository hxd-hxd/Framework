﻿// -------------------------
// 创建日期：2023/4/7 18:07:24
// -------------------------

using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace Framework.TextMeshProExpress
{
    /// <summary>
    /// 对 <see cref="TMP_Text"/> 的实现
    /// </summary>
    public class DropdownPro_TMPText : DropdownProAbstract<TMP_Text>
    {
        protected override void Start()
        {
            base.Start();

        }
    }
}