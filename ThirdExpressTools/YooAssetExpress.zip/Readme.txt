

对 YooAsset 资源热更插件的扩展。

注意：请在导入此扩展之前导入 YooAsset 插件，不然会报错。
	本工具编写时对应插件版本为 2.2.4

Github 仓库：https://github.com/tuyoogame/YooAsset/tree/main

下载安装
	通过PackageManager安装
	打开管理界面 Edit/Project Settings/Package Manager
	输入以下内容
	Name: package.openupm.cn
	URL: https://package.openupm.cn
	Scope(s): com.tuyoogame.yooasset


作为热更库，代码全部需要放在本地！！！
作为热更库，代码全部需要放在本地！！！
作为热更库，代码全部需要放在本地！！！
